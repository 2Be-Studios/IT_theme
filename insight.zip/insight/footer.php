		<footer>
			<div class="container text-center">
				<p><strong>© 2018 Insight IT.</strong></p>
			</div>
		</footer>
		<?php wp_footer(); ?>
	</body>
</html>
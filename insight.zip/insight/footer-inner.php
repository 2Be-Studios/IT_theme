		<footer class="page-footer__inner">
			<div class="container-fluid">
				<div class="row">
					<div class="float-left">
						<p><strong>© 2018 Insight IT.</strong></p>
					</div>
					<ul class="float-right footer-social__list">
						<li>

							<a href="https://www.facebook.com/MyInsight" target="_blank">
								<i class="fab fa-facebook-f"></i>
							</a>
						</li>
						<li>
							<a href="https://twitter.com/My_Insight" target="_blank">
								<i class="fab fa-twitter"></i>
							</a>
						</li>
						<li>
							<a href="https://www.linkedin.com/company/insight-i.t/" target="_blank">
								<i class="fab fa-linkedin-in"></i>
							</a>
						</li>
					</ul>
				</div>
				
			</div>
		</footer>
		<?php wp_footer(); ?>
	</body>
</html>